AnalyzerPro v1.0.0
MelecDSP

INSTALLATION
============

This installer will copy the following components:

1. AU (Audio Unit): ~/Library/Audio/Plug-Ins/Components/
2. VST3: ~/Library/Audio/Plug-Ins/VST3/
3. Standalone App: /Applications/

SYSTEM REQUIREMENTS
===================

- macOS 10.13 or later
- Intel or Apple Silicon Mac
- Compatible DAW (for AU/VST3 plugins)

MICROPHONE PERMISSION
=====================

The Standalone application requires microphone access to capture audio 
from input devices, including virtual loopback devices like BlackHole.
You will be prompted to grant permission on first launch.

SUPPORT
=======

For support, visit: https://www.melechdsp.com

Copyright © 2026 MelecDSP. All rights reserved.
